package com.exterro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

	
}
