
$(document).ready(function() {
	$('#form').click(function() {
		
		
		var name = $('#name').val();
	    var isValid = /^[a-zA-Z ]+$/.test(name); 

	    if (!isValid) {
	      alert('Please enter a valid name without special characters.');
	      return; 
	    }
		
	    
	    if (name.length > 30) {
            alert('Please enter a name with a maximum of 30 characters.');
            return;
        }
		
	    
	    var email = $('#email').val();
	    //regular expression pattern
	    var isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

	    if (!isValidEmail) {
	      alert('Please enter a valid email address.');
	      return;
	    }
	    var phone = $('#phone').val();
	    var isValidPhone = /^\d{10}$/.test(phone);

	    if (!isValidPhone) {
	      if (phone.length === 0) {
	        alert('Please enter a phone number.');
	      } else if (phone.length < 10) {
	        alert('Please enter a 10-digit phone number.');
	      } else {
	        alert('Please enter a valid phone number with digits only.');
	      }
	      return;
	    }

        var formData = {
            name: $('#name').val(),
            email: $('#email').val(),
            phoneNumber: $('#phone').val()
        };
        alert(JSON.stringify(formData))			
        
        console.log(JSON.stringify(formData))
        
        $.ajax({
            type: 'post',
            url: '/store',
            contenttype: "application/json",
			data: {data:JSON.stringify(formData)},
			datatype: 'text',
            success: function(response) {
                console.log(response)
                location.href=response;
            },
        });
    });
	
	$('#phone').on('input', function() {
	    var phone = $(this).val();
	    var sanitizedPhone = phone.replace(/[^\d]/g, '');

	    if (phone !== sanitizedPhone) {
	      $(this).val(sanitizedPhone);
	      alert('Please enter numbers only in the phone number field.');
	    }
	  });
	
});