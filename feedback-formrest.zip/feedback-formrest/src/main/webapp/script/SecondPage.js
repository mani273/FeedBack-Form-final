$(document).ready(function() {
  let cookie = {};
  document.cookie.split(';').forEach(function(el) {
    let [k,v] = el.split('=');
    cookie[k.trim()] = decodeURIComponent (v);
  });
   alert(JSON.stringify(cookie));                                                                                                                                                                                                                                                 
  $('#uname').text(cookie.name);
  $('#uphone').text(cookie.phone);
  $('#uemail').text(cookie.email);

  var batch = 'java';
  var burl = `/data/api/questions/${batch}`;
  $.ajax({
    type: 'GET',
    url: burl,
    dataType: 'json',
    success: function(data) {
      var questionsDiv = $('#questions');
		console.log(data);
		 questionCount = data.length;
      for (var i = 0; i < data.length; i++) {
        var question = data[i];
        var questionId = question.id;
        var questionText = question.text1;
        var questionHeader = $('<h4>').text(questionText).attr('id', 'question_' + questionId);
        questionsDiv.append(questionHeader);
        for (var j = 1; j <= 5; j++) {
        	  var optionId = 'question_' + questionId + '_option_' + j;
        	  var radioBtn = $('<input>').attr({
        	    type: 'radio',
        	    name: 'question_' + questionId,
        	    id: optionId,
        	    value: j,
        	    required: true  
        	  });
          var label = $('<label>').attr('for', optionId).text(j);
          questionsDiv.append(radioBtn).append(label);
        }
        questionsDiv.append('<br><br>');
      }
    }
  });
  
  
  
//cookies
var encryptedUserId = getCookieValue('id');
var decryptedUserId;

// Function to retrieve the value of a cookie
function getCookieValue(cookieName) {
	  var name = cookieName + "=";
	  var decodedCookie = decodeURIComponent(document.cookie);
	  var cookieArray = decodedCookie.split(';');
	  for (var i = 0; i < cookieArray.length; i++) {
	    var cookie = cookieArray[i].trim();
	    if (cookie.indexOf(name) === 0) {
	      return cookie.substring(name.length, cookie.length);
	    	}
	  	}
	  return "";
	}


console.log(encryptedUserId)
// Function to make the request for decryption
function makeDecryptionRequest(encryptedValue) {
	  $.ajax({
	    type: 'POST',
	    url: '/decrypt',
	    data: { encryptedValue: encryptedValue },
	    dataType: 'text',
	    success: function(decryptedValue) {
	      decryptedUserId = decryptedValue;
	      console.log("Decrypted user ID: " + decryptedUserId);
	      // Proceed with retrieving user details using the decrypted user ID
	      retrieveUserDetails(decryptedUserId);
	    },
	    error: function() {
	      console.log('Error decrypting user ID');
	    	}
 	 });
}

var dataOfUser ;
// Function to retrieve user details
function retrieveUserDetails(id) {
  $.ajax({
    type: 'get',
    url: `/data/api/user/${id}`,
    datatype: 'json',
    success: function(user) {
		alert(JSON.stringify(user));
    	dataOfUser = user;
    
      $('#uname').text(user.name);
      $('#uphone').text(user.phoneNumber);
      $('#uemail').text(user.email);
    },
    error: function() {
      console.log('Error retrieving user details');
    }
  });
}

// Call the decryption request function with the encrypted user ID
makeDecryptionRequest(encryptedUserId);

  
  $('#formdata').click(function() {
    var questionIds = [];
    var answerValues = [];
    
    $('input[type="radio"]:checked').each(function() {
      var questionId = $(this).attr('name').replace('question_', '');
      var answerValue = $(this).val();

      questionIds.push(questionId);
      answerValues.push(answerValue);
    
    });
   
 
  
    
    var javaresponse = {
      name: dataOfUser.name,
      phoneNumber: dataOfUser.phone,
      email: dataOfUser.email,
      question: questionIds,
      answer: answerValues,
      batch: "java"
      
    };
    
    alert(JSON.stringify(javaresponse));
    $.ajax({
  	  type: 'post',
  	  url: `/data/api/submit1`,
  	  contenttype:"application/json",
  	  datatype: 'text',
  	  data: {uu: JSON.stringify(javaresponse) },
  	  
  	  success: function(response) {
  	    location.href = response;
  	  }
  	});
  });
});