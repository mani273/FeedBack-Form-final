   //cookies
      var encryptedUserId = getCookieValue("id");
      var decryptedUserId;

      //Function to retrieve the value of a cookie
      function getCookieValue(cookieName) {
        var name = cookieName + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var cookieArray = decodedCookie.split(";");
        for (var i = 0; i < cookieArray.length; i++) {
          var cookie = cookieArray[i].trim();
          if (cookie.indexOf(name) === 0) {
            return cookie.substring(name.length, cookie.length);
          }
        }
        return "";
      }

      console.log(encryptedUserId);
      //Function to make the request for decryption
      function makeDecryptionRequest(encryptedValue) {
        $.ajax({
          type: "POST",
          url: "/decrypt",
          data: { encryptedValue: encryptedValue },
          dataType: "text",
          success: function (decryptedValue) {
            decryptedUserId = decryptedValue;
            console.log("Decrypted user ID: " + decryptedUserId);
            // Proceed with retrieving user details using the decrypted user ID
            retrieveUserDetails(decryptedUserId);
          },
          error: function () {
            console.log("Error decrypting user ID");
          },
        });
      }
     //Call the decryption
      makeDecryptionRequest(encryptedUserId);


      var dataOfUser;
      //Function to retrieve user details
      function  retrieveUserDetails(userId) {
        $.ajax({
          type: "GET",
          url: "/data/api/user/" + userId,
          dataType: "json",
          success: function (user) {
            dataOfUser = user;
            console.log(dataOfUser);
            getResults(dataOfUser)
          },
          error: function () {
            console.log("Error retrieving user details");
          },
        });
      }
   

  
 function getResults(dataOfUser){
   var selectedBatch = getQueryParamValue("data");
      var batch = selectedBatch ? selectedBatch : "allData";
      //get questions
      var questionData;
      var burl = `/data/api/questions/${batch}`;
      $.ajax({
        type: "GET",
        url: burl,
        dataType: "json",
        success: function (data) {
          console.log(data);
          questionData = data;

        },
      });

      var burl = `/data/api/results/${batch}`;
      $.ajax({
        type: "GET",
        url: burl,
        dataType: "json",
        success: function (data) {
          var tbody = $("#dataTable tbody");
          tbody.empty();
          data.forEach(function (result) {
            var text1;
            if (result.user.email == dataOfUser.email) {
              for (const obj of questionData) {
                if (obj.id == result.question) {
                  text1 = obj.text1;
                  break;
                }
              }
              var row =
                "<tr>" +
                "<td>" +
                text1 +
                "</td>" +
                "<td>" +
                result.ans +
                "</td>" +
                "</tr>";

              tbody.append(row);
            }
          });
        },
        error: function (xhr, status, error) {
          console.log("Error: " + error);
        },
      });

      }
      

      // Get cookie values

      function getQueryParamValue(param) {
        var urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
      }

      let cookie = {};
      document.cookie.split(";").forEach(function (el) {
        let [k, v] = el.split("=");
        cookie[k.trim()] = v;
      });

      // Send email when button is clicked
      $("#sendEmailBtn").click(function () {
        var userId = cookie.id;
        var email;
        console.log("Hello"); // Assuming the user ID is stored in the cookie
        $.ajax({
          type: "GET",
          url: "/data/api/user/" + userId,
          dataType: "json",
          success: function (data) {
            email = data.email;
            console.log(data.email);
            var subject = "Results";
            var body = $("#results").html();

            $.ajax({
              type: "POST",
              url: "/sendEmail",
              data: {
                recipientEmail: email,
                subject: subject,
                body: body,
              },

              success: function (response) {
                console.log("Email sent successfully!");
              },
              error: function (xhr, status, error) {
                console.log("Error sending email: " + error);
              },
            });
          },
          error: function () {
            console.log("Error retrieving user details");
          },
        });
      });